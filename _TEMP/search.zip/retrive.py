import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer

q = input('Masukan Kata Kunci : ')
print('-'*100)

docs = []
with open(r'documents.txt', 'r') as fp:
    for item in fp:
        x = item[:-1]
        docs.append(x)

docs_clean = []
with open(r'documents_clean.txt', 'r') as fp:
    for item in fp:
        x = item[:-1]
        docs_clean.append(x)

vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(docs_clean)

# Create a DataFrame
df = pd.DataFrame(X.T.toarray(), index = vectorizer.get_feature_names_out())

print("query:", q)
print("Berikut artikel dengan nilai cosine similarity tertinggi: ")
q = [q]
q_vec = vectorizer.transform(q).toarray().reshape(df.shape[0],)
sim = {}
for i in range(10):
    sim[i] = np.dot(df.loc[:, i].values, q_vec) / np.linalg.norm(df.loc[:, i]) * np.linalg.norm(q_vec)

sim_sorted = sorted(sim.items(), key=lambda x: x[1], reverse=True)

for k, v in sim_sorted:
    if v != 0.0:
        print("Nilai Similaritas:", v)
        print(docs[k])
        print()