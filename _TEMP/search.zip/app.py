from flask import Flask, request, render_template
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer

# Declare a Flask app
app = Flask(__name__)

# Main function here
@app.route('/', methods=['GET', 'POST'])
def main():
    # If a form is submitted
    if request.method == "POST":

        # Get values through input bars
        q = request.form.get("query")
        docs = []
        with open(r'documents.txt', 'r') as fp:
            for item in fp:
                x = item[:-1]
                docs.append(x)

        docs_clean = []
        with open(r'documents_clean.txt', 'r') as fp:
            for item in fp:
                x = item[:-1]
                docs_clean.append(x)

        vectorizer = TfidfVectorizer()
        X = vectorizer.fit_transform(docs_clean)

        # Create a DataFrame
        df = pd.DataFrame(X.T.toarray(), index = vectorizer.get_feature_names_out())

        q = [q]
        q_vec = vectorizer.transform(q).toarray().reshape(df.shape[0],)
        sim = {}
        for i in range(10):
            sim[i] = np.dot(df.loc[:, i].values, q_vec) / np.linalg.norm(df.loc[:, i]) * np.linalg.norm(q_vec)

        sim_sorted = sorted(sim.items(), key=lambda x: x[1], reverse=True)

        result = []
        for k, v in sim_sorted:
            if v != 0.0:
                result.append({
                    'sim' : v,
                    'doc' : docs[k]
                })        
    else:
        result = []
        
    return render_template("website.html", outputs = result)

# Running the app
if __name__ == '__main__':
    app.run(debug = True)